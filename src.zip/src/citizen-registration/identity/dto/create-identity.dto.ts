export class CreateIdentityDto {
    readonly NIN: string;
    readonly BVN?: string;
    readonly mobileNumber: string;
}
   